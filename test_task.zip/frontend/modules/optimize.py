######################################################
#
#
#               Data Optimization
#               
#               Date: 28/02/2021
#
#
#
#
######################################################


from typing import Sequence
import pandas as pd

from modules.get_data import GetAndSerializeData


ser_data = GetAndSerializeData()


class OptimizeAndInsert():


    
    def search_data(guid: str=None, 
                    sensor_name: str=None, 
                    search_start: str=None, 
                    search_end: str=None) -> Sequence[list]:

        generator = sorted(ser_data.get_sensor_data(guid = guid,
                                                    sensor_name=sensor_name, zipped=True), 
                                                    key=lambda x: x[1], reverse=False)

        sensor_values = []
        sensor_times = []

        def create_generator(generator, search_start, search_end):
            for x in generator:
                if(x[1]==search_start):
                    y=generator.index(x)
                    for i in range(y,len(generator)):
                        sensor_values.append(generator[i][0])
                        sensor_times.append(generator[i][1])
                        if(generator[i][1]==search_end):
                            break
            return sensor_values, sensor_times

        for x in generator:
            if(x[1]==search_start):
                start_i=generator.index(x)
            elif(x[1]==search_end):
                end_i=generator.index(x)

        try:
            if(start_i > end_i):
                sensor_values, sensor_times = create_generator(generator[::-1], search_start, search_end)
            else:
                sensor_values, sensor_times = create_generator(generator, search_start, search_end)
        except UnboundLocalError:
            return sensor_values, sensor_times

        return sensor_values, sensor_times

    
    def insert_table() -> str:

        sensor_one, sensor_times = ser_data.get_sensor_data(guid='70B3D5E390001111')
        sensor_two, _ = ser_data.get_sensor_data(guid='70B3D5E390001112')
        sensor_three, _ = ser_data.get_sensor_data(guid='70B3D5E390001113')
        sensor_four, _ = ser_data.get_sensor_data(guid='70B3D5E390001114')

        df = pd.DataFrame.from_records(index=sensor_times[:20],
                                    data=zip(sensor_one[:20], sensor_two[:20], sensor_three[:20], sensor_four[:20]), 
                                    columns=['70B3D5E390001111',
                                                '70B3D5E390001112',
                                                '70B3D5E390001113',
                                                '70B3D5E390001114'])
                
        return df.to_html(
                            escape=False, 
                            header=True,
                            justify='left',
                            bold_rows=True,
                            border=0,
                            index_names=False,
                            classes=['table table-sm table-striped table-bordered table-hover','small-text td-right']
                        )
