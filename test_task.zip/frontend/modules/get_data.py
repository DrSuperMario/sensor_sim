######################################################
#
#
#               Get Data by Request
#               
#               Date: 28/02/2021
#
#
#
#
######################################################


from typing import Sequence
import requests as req # type: ignore
from pprint import pprint

from datetime import datetime
import isodate



class GetAndSerializeData():

    def __init__(self) -> None:
        #URLs for data endpoints
        self.devices = "https://test-task.thinnect.net/devices"
        self.data_types = "https://test-task.thinnect.net/data_types"
        self.measurments = "https://test-task.thinnect.net/measurements"

    @classmethod
    def get_json(cls, url: str, tag: str=None) -> str:
        data = req.get(url)

        if(tag is not None):
            return [x[tag] for x in data.json() if x[tag]]

        return data.json()

    @classmethod
    def normalize_time(cls,time: str) -> str:
        return [datetime.strftime(isodate.parse_datetime(x), "%Y-%m-%d %H:%M:%S") for x in time]

    def get_devices(self) -> list:
        return self.get_json(url=self.devices, tag='guid')

    def get_data_types(self) -> list:
        return self.get_json(url=self.data_types, tag='name')

    def get_measurments(self, tag: str='timestamp') -> list:
        
        data = self.get_json(url=self.measurments, tag=tag)

        if(tag == 'timestamp'):
             return self.normalize_time(data)

        return data

    def get_sensor_data(self, guid: str=None, sensor_name: str=None, zipped=False) -> Sequence[list]:

        data = self.get_json(self.measurments)

        if(guid is not None):
            value = [x['value'] for x in data if x['device']['guid']==guid]
            timestamp = self.normalize_time([x['timestamp'] for x in data if x['device']['guid']==guid])
        elif(sensor_name is not None):
            value = [x['value'] for x in data if x['dataType']['name']==sensor_name]
            timestamp = self.normalize_time([x['timestamp'] for x in data if x['dataType']['name']==sensor_name])
        else:
            all_values_by_id = [[x['device']['guid'],x['value']] for x in data]    
            all_devices_by_id = [[x['dataType']['name'],x['value']] for x in data]

            return zip(all_values_by_id, all_devices_by_id)

        if(zipped):
            return zip(value,timestamp)

        return value,timestamp

    def main():
        ...
    
    def __repr__(self) -> str:
        return f"<{self.devices}>.<{self.data_types}>.<{self.measurments}>"

    def __str__(self) -> str:
        pprint(f"""devices URL : {self.devices} \n 
                   Data_types URL: {self.data_types} \n 
                   Measurments URL: {self.measurments}""")