######################################################
#
#
#               Forms validation
#               
#               Date: 28/02/2021
#
#
#
#
######################################################

from flask_wtf import FlaskForm
from flask_wtf.recaptcha import validators
from wtforms import PasswordField, StringField, SubmitField, SelectField
from wtforms.validators import DataRequired

#Loging form
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])

#all the other forms
class SelectorForm(FlaskForm):
 
    select_date_start = SelectField(
                                    'Data start',                               
                                )
    select_date_end = SelectField(
                                    'Data start',                              
                                )
    submit_date = SubmitField('Search')

    select_sensor = SelectField('Sensor')
    select_device = SelectField('Device')
