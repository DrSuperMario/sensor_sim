# sensor_simulator

# Test task by Mario Muuk
## Dependencies
* Python 3
* Python packages:
    * Flask, 
    * flask_login, 
    * wekzeug.security,
    * SQLAlchemy,
    * SQLite, 
    * Flask_wtf_forms, 
    * wtfforms, 
    * isodate, 
    * pandas, 
    * typing, 
    * pprint

## Instructions for running the development server

Login for test_taks: 
    - User: test
    - Passwd: test

Install dependencies:
```bash

pip install -r requirements.txt

```

Run development server
```bash

python run.py

```
### generate admin
Simple user generator

```bash

python generate_admin.py --username <user.name> --password <password>

```

The server will be running on the port `5080`.
Note: Running the project will create a sqlite database in the current
folder
named `data.db`.
