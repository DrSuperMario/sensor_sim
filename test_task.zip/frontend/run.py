###################################################
#
#
#           Frontend for Device Manager
#   
#           Using: Flask, flask_login, wekzeug.security,
#                  SQLAlchemy, SQLite, Flask_wtf_forms, 
#                  wtfforms, numpy, isodate, pandas, 
#                  typing, pprint
#
#           Created by: Mario Muuk
#           Date: 28/02/2021 
#
####################################################

#Import all packages
from flask import (
                    Flask, 
                    redirect, 
                    flash, 
                    url_for,
                    json
                )
from flask.globals import request
from flask.templating import render_template
from flask_login import (
                         LoginManager, 
                         login_manager, 
                         login_user, 
                         logout_user 
                    )
from flask_login.utils import login_required

from werkzeug.security import check_password_hash

from modules.forms import LoginForm, SelectorForm
from modules.admin import Admin
from modules.get_data import GetAndSerializeData
from modules.optimize import OptimizeAndInsert as opt

from db import db


app = Flask(__name__)
login_manager = LoginManager()

ser_data = GetAndSerializeData()

#config all endpoints
app.config['SECRET_KEY'] = 'ExtreamlySecretSecretKey'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///data.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['PROPAGATE_EXCEPTIONS'] = True


#init app and loging manager
db.init_app(app)
login_manager.init_app(app)

#login endpoint
@login_manager.user_loader
def user_loader(user_id):
    return Admin.query.filter_by(username=user_id).first()

@app.route('/login', methods=['GET','POST'])
@app.route('/', methods=['GET','POST'])
def login():

    error = None

    form = LoginForm()
   
    if((request.method == 'POST') and (form.validate)):
        user = Admin.query.filter_by(username=form.username.data).first()
        if((not user) or (not check_password_hash(user.password, form.password.data))):
            flash("NO match for the old guy")
        else:
            user.authenticated = True
            db.session.add(user)
            db.session.commit()
            login_user(user, remember=True)
            return redirect(url_for('welcome'))
            
        
 
    return render_template('index.html',form=form, title = error if error != None else "happy hunting" )    

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/welcome', methods=['GET','POST'])
@login_required
def welcome():
    form = SelectorForm()
    form.select_device.choices=ser_data.get_devices()
    form.select_sensor.choices=ser_data.get_data_types()


    return render_template('home.html', 
                        devices = ser_data.get_devices(),
                        data_types = ser_data.get_data_types(),
                        form = form,
                        table_data =opt.insert_table() ,
                        show_dt_lb=False,
                    )


@app.route('/by_id/<guid_id>', methods=['GET','POST'])
@login_required
def all_routes(guid_id):

    form = SelectorForm()

    SENSOR = guid_id

    sensor_value, sensor_time  = ser_data.get_sensor_data(guid=SENSOR)
    form.select_date_start.choices = sensor_time
    form.select_date_end.choices = sensor_time


    if((request.method == 'POST') and (form.submit_date.data)):
        
        sensor_value, sensor_time=opt.search_data(
                                                    guid=SENSOR, 
                                                    search_start=form.select_date_start.data, 
                                                    search_end=form.select_date_end.data,
                                            )
        if not sensor_value:
            sensor_value, _ = ser_data.get_sensor_data(guid=SENSOR)
      
        return render_template('home.html',
                        devices = ser_data.get_devices(),
                        data_types = ser_data.get_data_types(),
                        p_name=guid_id, 
                        form = form,
                        show_dt_lb=True,
                        labels = json.dumps(sensor_time),
                        values = json.dumps(sensor_value))
    

    return render_template('home.html',
                            devices = ser_data.get_devices(), 
                            data_types = ser_data.get_data_types(),
                            form = form,
                            p_name=guid_id,
                            show_dt_lb=True, 
                            labels = json.dumps(None),
                            values = json.dumps(sensor_value))


@app.route('/by_sensor/<sensor_name>', methods=['GET','POST'])
@login_required
def data_type_c(sensor_name):
    form = SelectorForm()

    SENSOR = sensor_name
    sensor_value, sensor_time  = ser_data.get_sensor_data(sensor_name = SENSOR)
    form.select_date_start.choices = sensor_time
    form.select_date_end.choices = sensor_time
    
    if((request.method == 'POST') and (form.submit_date.data)):

        sensor_value, sensor_time=opt.search_data(
                                                sensor_name=SENSOR, 
                                                search_start=form.select_date_start.data, 
                                                search_end=form.select_date_end.data,
                                                )
        if not sensor_value:
            sensor_value, _ = ser_data.get_sensor_data(sensor_name=SENSOR)

        return render_template('home.html',
                        devices = ser_data.get_devices(),
                        data_types = ser_data.get_data_types(), 
                        form = form,
                        show_dt_lb=True,
                        p_name=sensor_name, 
                        labels = json.dumps(sensor_time),
                        values = json.dumps(sensor_value))

    return render_template('home.html', 
                            form = form,
                            p_name=sensor_name,
                            show_dt_lb=True, 
                            devices = ser_data.get_devices(),
                            data_types = ser_data.get_data_types(),
                            labels = json.dumps(None),
                            values = json.dumps(sensor_value))

#Runn everything
if(__name__=="__main__"):

    with app.app_context():
        db.create_all()
    
    app.run(port=5080, debug=True)