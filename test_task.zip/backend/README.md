# sensor_simulator

# Test task by Mario Muuk
## Dependencies
* Python 3
* Python packages:
 * flask
 * flask-restful
 * sqlalchemy
 * flask_jwt_extended
 * typing

## Instructions for running the development server
Install dependencies:
```bash
pip install -r requirements.txt
```
Run development server
```bash
python run_server.py
```
The server will be running on the port `5060`.
Note: Running the project will create a sqlite database in the current
folder
named `simplesink.db`.
