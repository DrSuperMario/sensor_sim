##############################
#       
#       /devices
#       date: 28/02/2021
#
##############################

from typing import Any, Sequence
from flask_restful import Resource, reqparse, fields, marshal_with
from flask_jwt_extended import jwt_required


from modules.measurments import MeasurmentsList


#Add all arguments for parsing
parser = reqparse.RequestParser()

parser.add_argument(
                    'value',
                    dest = 'value', 
                    type=int, 
                    required=True, 
                    help="You need VALUE for the measurment"
                )
parser.add_argument(
                    'device',
                    dest='device', 
                    type=dict,
                    action='append', 
                    required=True, 
                    help="You need GUID for the measurment"
                ) 
parser.add_argument(
                    'dataType',
                    dest='dataType', 
                    type=dict, 
                    action='append',
                    required=True, 
                    help="You need DEVICE for the measurment"
                )

setup_fields = {
        "id": fields.Integer,
        "timestamp": fields.String,
        "value": fields.Float,
        "device": fields.Nested({
            "guid": fields.String
        }),
        "dataType": fields.Nested({
            "name": fields.String,
        }),
}

class Measurment(Resource):

    """
    get: Get json response from post name
    post: post device
    GetAllMeasurments-GET: get all enpoints
    """

                                            

    #comment to disable security
    #@jwt_extended
    @marshal_with(setup_fields)
    def post(self) -> Sequence[Any]:

        value_data = parser.parse_args()
        #little bit of spaghetti magic
        x = value_data['device'][0]['guid'],value_data['dataType'][0]['name']
        y = value_data['value']
        #breakpoint()
        measur = MeasurmentsList(y,*x)
        try:
            measur.save_to_db()
        except:
            return {"message":"An error occured while saving"}, 400


        return measur.json(),201

class GetAllMeasurments(Resource):
    def get(self):
        return [x.json() for x in MeasurmentsList.query.all()]
    

