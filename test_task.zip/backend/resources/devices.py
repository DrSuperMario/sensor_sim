##############################
#       
#       /devices
#       date: 28/02/2021
#
##############################

from typing import Any, Sequence
from flask_restful import Resource, reqparse
from flask_jwt_extended import jwt_required

from modules.devices import DeviceList


class Device(Resource):

    """
    get: Get json response from post name
    post: post device
    GetAllDevices-GET: get all enpoints
    """

    parser = reqparse.RequestParser()

    parser.add_argument('guid', type=str, required=False, help="You need UID of the device")

    def get(self, guid: str) -> Sequence[Any]:
        guid = DeviceList.find_by_guid(guid)
        if(guid):
            return guid.json(), 201

        return {"message":"Something went wrong while posting"}, 400

    #comment to disable security
    #@jwt_required
    def post(self, guid_id: int) -> Sequence[Any]:
        guid_data = Device.parser.parse_args()
        

        uid = DeviceList(guid_id, **guid_data)
        try:
            uid.save_to_db()
        except:
             return {"message":"An error occured while saving"}, 400

        return uid.json(), 201

class GetAllDevices(Resource):
    #get all data_types from db
    def get(self) -> Sequence[Any]:
        return [x.json() for x in DeviceList.query.all()]

