##############################
#       
#       /data_types 
#       date: 28/02/2021
#
##############################

from typing import Any, Sequence
from flask_restful import Resource, reqparse
from flask_jwt_extended import jwt_required

from modules.data_types import DataTypesList

#init resources for the datatypes
class DataTypes(Resource):

    """
    get: Get json response from post name
    post: post data_type
    GetAllDataTypes-GET: get all enpoints

    """

    #use restful reqparse to parse requests
    parser = reqparse.RequestParser()
    #add arguments to parse
    parser.add_argument('name', type=str, required=True, help="Name of the data type")

    def get(self, name: str) -> Sequence[Any]:
        name = DataTypesList.find_by_name(name)
        if(name):
            return name.json(), 201

        return {"message":"Something went wrong while posting"}, 400

    #comment to disable security
    #@jwt_required
    def post(self, name_id) -> Sequence[Any]:

        type_data = DataTypes.parser.parse_args()

        device_name = DataTypesList(name_id, **type_data)

        try:
            device_name.save_to_db()
        except:
             return {"message":"An error occured while saving"}, 400

        return device_name.json(), 201


class GetAllDataTypes(Resource):
    #get all data_types from db
    def get(self) -> Sequence[Any]:
        return [x.json() for x in DataTypesList.query.all()]