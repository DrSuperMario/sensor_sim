##############################
#       
#       /sink POST
#       date: 28/02/2021
#
##############################


from typing import Any, Sequence
from flask_restful import Resource, reqparse, fields, marshal_with
from flask_jwt_extended import jwt_required

from modules.sink import SinkList

#Add all arguments for parsing
parser = reqparse.RequestParser()

parser.add_argument('source', 
                    dest='source',
                    type=str, 
                    required=True, 
                    help="You need source of the device")
parser.add_argument('timestamp_arrival', 
                    dest='timestamp_arrival', 
                    type=float, 
                    required=True, 
                    help="You need arrival of the device")
parser.add_argument('values',
                    dest='values',                   
                    type=dict,
                    action='append', 
                    required=True, 
                    help="You need production of the device")

#add schema for the fields
setup_fields = {
    "source": fields.String,
    "timestamp_arrival": fields.String,
    "values": fields.List(fields.Nested({
        "timestamp_production": fields.String,
        "type": fields.String,
        "value": fields.String,
    })),
}


class Sink(Resource):

    """
    get: Get json response from post name
    post: post device
    GetAllSinks-GET: get all enpoints
    """
    
    #init post with marshal 
    @marshal_with(setup_fields)
    def post(self) -> Sequence[Any]:
        data = parser.parse_args()

        #This is the macarone | spaghetti aka hardcoded -->
        y = data['source'],data['timestamp_arrival']
        x = data['values'][0]     

        save_data = SinkList(*y,**x)
        
        try:
            save_data.save_to_db()
        except:
            return {"message":"An error occured while saving"}, 400


        return save_data.json(),200

    
class GetAllSinks(Resource):
    def get(self) -> Sequence[Any]:
        return [x.json() for x in SinkList.query.all()]
