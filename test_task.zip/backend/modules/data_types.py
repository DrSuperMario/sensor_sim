##############################
#       
#       /data_types 
#       date: 28/02/2021
#
##############################


from typing import Any, Sequence

from db import DB

#init modul and add db
class DataTypesList(DB.Model):
    """

    __tablename__ = Tabel name for the DB
    name = Name inside of a table
    uid = unique id inside of a table

    """

    __tablename__= 'dataTypes'

    name = DB.Column(DB.String(20), primary_key=True, nullable=False)
    name_id = DB.Column(DB.Integer, DB.ForeignKey('measurments.id'))
    uid = DB.relationship('MeasurmentsList')


    def __init__(self,name_id: int, name: str) -> str:
        self.name_id = name_id
        self.name = name

    def __repr__(self) -> str:
        return f"<{self.name}>.<{self.name_id}>"
        
    #Getting JSON response
    def json(self) -> Sequence[Any]:
        return {'name':self.name}
    
    #Getting data
    def get_data(self) -> str:
        return self.name

    #Find table entry by name
    @classmethod
    def find_by_name(cls, name: str) -> Sequence[Any]:
        return cls.query.filter_by(name=name).first()
    
    #save to db
    def save_to_db(self) -> None:
        DB.session.add(self)
        DB.session.commit()

    #delete from db
    def delete_from_db(self) -> None:
        DB.session.delete(self)
        DB.session.commit()

  

