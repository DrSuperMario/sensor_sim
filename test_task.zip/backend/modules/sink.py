##############################
#       
#       /sink POST
#       date: 28/02/2021
#
##############################

from db import DB

from typing import Any, Sequence

class SinkList(DB.Model):

    """

    __tablename__ = Tabel name for the DB
    id = primary key for table
    timestamp_arrival = timestamp sent when arrived
    timestamp_production = timestamp sent when produces
    type = type of the device
    value  = value of devices

    """

    __tablename__= "sink"

    id = DB.Column(DB.Integer, nullable=False, primary_key=True)
    source = DB.Column(DB.String(30), nullable=False)
    timestamp_arrival = DB.Column(DB.Float, nullable=False)
    timestamp_production = DB.Column(DB.Integer, nullable=False)
    type = DB.Column(DB.String(20), nullable=False)
    value = DB.Column(DB.PickleType, nullable=False)
    

    def __init__(
                 self, source: str, 
                 timestamp_arrival: float,
                 timestamp_production: int,
                 type: str,
                 value: int) -> None:
        self.source = source
        self.timestamp_arrival = timestamp_arrival
        self.timestamp_production = timestamp_production
        self.type = type
        self.value = value
        
    def __repr__(self) -> str:
        return f"<{self.id}>.<{self.source}.<{self.timestamp_arrival}.<{self.timestamp_production}>"


    def json(self) -> Sequence[Any]:
        
        return {
                "source":self.source,
                "timestamp_arrival": float(self.timestamp_arrival),
                "values":[ 
                            {
                                "timestamp_production":int(self.timestamp_production),
                                "type":self.type,
                                "value": int(self.value)
                            }
                        ]
                
        } 

    @classmethod
    def find_by_id(cls, id: str) -> Sequence[Any]:
        return cls.query.filter_by(id=id).first()

    def save_to_db(self) -> None:
        DB.session.add(self)
        DB.session.commit()

    def delete_from_db(self) -> None:
        DB.session.delete(self)
        DB.session.commit()

    