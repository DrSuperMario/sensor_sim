##############################
#       
#       /devices
#       date: 28/02/2021
#
##############################

from db import DB

from typing import Any, Sequence


class DeviceList(DB.Model):

    """

    __tablename__ = Tabel name for the DB
    id = primary key for table
    guid = id of the device
    guid_id = foreignkey to connect tables
    measurments = releatsionship between tables

    """

    __tablename__ = 'device'

    id = DB.Column(DB.Integer, primary_key=True)
    guid = DB.Column(DB.String(30), nullable=False)
    
    guid_id = DB.Column(DB.Integer, DB.ForeignKey('measurments.id'))
    measurments = DB.relationship("MeasurmentsList")

    def __init__(self,guid_id: int, guid: str, ) -> None:
        self.guid_id = guid_id
        self.guid = guid
        
    def __repr__(self) -> str:
        return f"<{self.id}>.<{self.guid}>"

    def json(self) -> dict:
        return {'guid': self.guid}

    def get_guid(self) -> str:
        return self.guid

    @classmethod
    def find_by_guid(cls, guid_id: str) -> Sequence[Any]:
        return cls.query.filter_by(guid=guid_id).first()

    def save_to_db(self) -> None:
        DB.session.add(self)
        DB.session.commit()

    def delete_from_db(self) -> None:
        DB.session.delete(self)
        DB.session.commit()
  
