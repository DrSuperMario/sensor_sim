##############################
#       
#       /measurments
#       date: 28/02/2021
#
##############################

from datetime import datetime, time
from enum import auto
from typing import Any, Sequence

from db import DB


class MeasurmentsList(DB.Model):

    """

    __tablename__ = Tabel name for the DB
    id = primary key for table
    timestamp = timestamp of the device
    value = value of the device
    measurments = releatsionship between tables
    guid = relationship with devicelist
    data = relationship with dataTypes

    """

    __tablename__ = 'measurments'

    id = DB.Column(DB.Integer, primary_key=True, autoincrement=True, nullable=False)
    timestamp = DB.Column(DB.String(30), nullable=False)
    value = DB.Column(DB.Integer, nullable=False)
    device = DB.Column(DB.String(20), nullable=False)
    dataType = DB.Column(DB.String(20), nullable=False)
    

    def __init__(self, value: int, device: str, dataType: str,  timestamp: str=datetime.now().isoformat(),) -> None:

        self.value = value
        self.device = device
        self.dataType = dataType
        self.timestamp = timestamp
      

    def __repr__(self) -> str:
        return f"<{self.id}>.<{self.device}.<{self.timestamp}.<{self.value}>"
       
    
    def json(self) -> Sequence[Any]:
        
    
        return {
                'id':int(self.id),
                'timestamp':self.timestamp,
                'value':int(self.value),
                'device':{
                    'guid':str(self.device)
                },  
                'dataType':{
                    'name':str(self.dataType)
                    }
                }
    
    @classmethod
    def find_by_id(cls, id: int) -> Sequence[Any]:
        return cls.query.filter_by(id=id).first()

    @classmethod
    def find_all_measurments(cls) -> Sequence[Any]:
        return cls.query.all()

    def save_to_db(self) -> None:
        DB.session.add(self)
        DB.session.commit()

    def delete_from_db(self) -> None:
        DB.session.delete(self)
        DB.session.commit() 

