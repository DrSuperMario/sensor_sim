#########################################
#
#
#      Backend For Device Manager
#           
#      Using: Flask_restful, API 
#       
#      Date: 28/02/2012
#
#      By: Mario Muuk
#
##########################################

#Global imports
import os

from flask import Flask, request
from flask_restful import Api
from flask_jwt_extended import JWTManager

#Local Imports
from resources.devices import Device, GetAllDevices
from resources.data_types import DataTypes, GetAllDataTypes
from resources.measurments import Measurment, GetAllMeasurments
from resources.sink import Sink, GetAllSinks

from db import DB


app = Flask(__name__)

#Start of API config
#Using SQLite and SQLAlchemy
app.config['DEBUG'] = True
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL', 'sqlite:///simplesink.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['PROPAGATE_EXEPTIONS'] = True
#EXtreamly secret secret key
app.secret_key = 'verySecretSercretKey'

#API and JWT basic security initialization
api = Api(app)
jwt = JWTManager(app)

#addind all resources to API
api.add_resource(GetAllDevices,'/devices')
api.add_resource(Device,'/devices/<int:guid_id>')
api.add_resource(GetAllDataTypes,'/data_types')
api.add_resource(DataTypes,'/data_types/<int:name_id>')
api.add_resource(GetAllMeasurments,'/measurments')
api.add_resource(Measurment,'/measurments')
api.add_resource(Sink, '/sink')
api.add_resource(GetAllSinks, '/sink')


if(__name__=="__main__"):
    
    #Starting API
    
    DB.init_app(app)

    @app.before_first_request
    def first_request():
        DB.create_all()

    app.run(threaded=True, port=5060)