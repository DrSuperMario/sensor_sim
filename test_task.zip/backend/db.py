#Import flask sqlalchemy
from flask_sqlalchemy import SQLAlchemy

#init sqlalchemy
DB = SQLAlchemy()